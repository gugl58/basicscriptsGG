#' Constructor for S3 RuntimeC-Class
#'
#' Invokes a RuntimeC-Object holding a matrix with 5 cols and 0 rows where future
#' time-points are stored
#'
#' @return RuntimeC-object
#' @export
#'
#' @examples
#' rt_object <- RuntimeC()
RuntimeC <- function() {
	value  <- list(mat=matrix(nrow=0, ncol=5))
	colnames(value$mat) <- c("TotalUserCPUtime", "SystemCPUtime",
							 "realTime", "", "")
	# class can be set using class() or attr() function
	attr(value, "class") <- "RuntimeC"
	value
}


#' Adding timepoints
#'
#' Adds a named timepoint to object
#'
#' @param object RuntimeC-class object
#' @param name   Name of time point
#'
#' @return object plus additional named timepoint
#' @export
#'
#' @examples
#' library(basicscriptsGG)
#' rt_object <- RuntimeC()
#' rt_object <- add.timepoint(rt_object, "startpoint")			# add new timepoint NOW
#' rt_object <- add.timepoint(rt_object, "fun1")			# add new timepoint NOW
#' Sys.sleep(1) # placeholder for ultra cool function/script
#' rt_object <- add.timepoint(rt_object, "fun2")			# add new timepoint NOW
#' Sys.sleep(0.1)
#' rt_object <- add.timepoint(rt_object, "fun3")			# add new timepoint NOW
#' Sys.sleep(.2)
add.timepoint <- function(object, name){ UseMethod("add.timepoint")}
add.timepoint.RuntimeC <- function(object, name) {
	object$mat <- rbind(object$mat, proc.time())
	rownames(object$mat)[dim(object$mat)[1]] <- name
	return(object)
}

#' Finalize the RuntimeC-Object
#'
#' Adds a summary of all times in RuntimeC and calculates the relative times for
#' each function (Instead of the absolute time of proc.time())
#' Should be done only once, multiple times yield in pointless matrix. Therefore,
#' usually it can be done only once, except you force it by setting forceFinal=TRUE.
#'
#'
#' @param object     RuntimeC-object
#' @param forceFinal Forces adding the sumary and calculating the relative times
#'
#' @return object with 2 summary rows and all rows in relative times.
#' @export
#'
#' @examples
#' library(basicscriptsGG)
#' rt_object <- RuntimeC()
#' rt_object <- add.timepoint(rt_object, "startpoint")			# add new timepoint NOW
#' rt_object <- add.timepoint(rt_object, "fun1")			# add new timepoint NOW
#' rt_object <- absTOsingleTimes(rt_object)	# subtract the first for (starting point)

absTOsingleTimes <- function(object, forceFinal){ UseMethod("absTOsingleTimes")}
absTOsingleTimes.RuntimeC <- function(object, forceFinal=FALSE) {
	if(dim(object$mat)[1] <= 1)
	{
		return(object)
	}
	final.rowname <- "Total time - Sum: min"
	if(rownames(object$mat)[dim(object$mat)[1]] == final.rowname && !forceFinal)
	{
		print("Object already finished")
		return(object)
	}
	object <- add.timepoint(object, "Final")
	object$mat <- sweep(object$mat, 2, object$mat[1,], "-")# subtract first row from all rows
	for(row in dim(object$mat)[1]:2){	# with this loop, every process shows its single time
		# (meaning: no absolute inkremental values for the "realTime")
		object$mat[row, ] <- object$mat[row, ]-object$mat[row-1,]
		if(object$mat[row, 2] < 0) object$mat[row, 1:3] <- 0
	}
	rn <- rownames(object$mat)
	object$mat <- object$mat[-1, ] 		# omit 1. element
	rownames(object$mat) <- rn[- length(rn)] # omit last element

	total.sum <- apply(object$mat, 2, sum)
	object$mat <- rbind(object$mat, total.sum)
	rownames(object$mat)[dim(object$mat)[1]] <- "Total time - Sum: sec"
	object$mat <- rbind(object$mat, total.sum/60)
	rownames(object$mat)[dim(object$mat)[1]] <- final.rowname
	return(object)
}


write <- function(x, ...) UseMethod("write")
write.default <- base::write
write.RuntimeC <- function(obj, file)
{
	write.table(obj$mat, file=file, sep = "\t")
}
